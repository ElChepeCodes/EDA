/*
 * Estructuras de datos
 * Autor: Jose Luis Gutierrez Espinosa
 */
package Hash;

/**
 *
 * @author jlgut
 */
public class BloomFilter {
    private boolean [] list;
    private HashTable data;
    int cont, tam;
    
    public BloomFilter(){
        tam = 100;
        list = new boolean[tam];
        for (int i = 0; i< list.length; i++)
            list[i] = false;
        cont = 0;
        data = new HashTable(tam);
    }//builder
    
    private <T> int hash1(T el){
        String toSt = el.toString();
        int hash = toSt.charAt(0);
        for (int i = 0; i< toSt.length(); i++){
            hash *= toSt.charAt(i);
        }//for
        return hash % list.length;
    }//method
    
    private <T> int hash2(T el){
        String toSt = el.toString();
        int hash = toSt.charAt(0);
        for (int i = 0; i< toSt.length(); i++){
            hash += toSt.charAt(i);
        }//for
        return hash % list.length;
    }//method
    
    private <T> int hash3(T el){
        String toSt = el.toString();
        int hash = toSt.charAt(0);
        for (int i = 0; i< toSt.length(); i++){
            hash += toSt.charAt(i)*toSt.charAt(i);
        }//for
        return hash % list.length;
    }//method
    
    public void add(){
        
    }//method
}//class
