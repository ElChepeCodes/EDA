package Tareas;

import java.util.Iterator;

public class LinkedBT<T> implements BinaryTreeADT<T> {

    private NodoBT<T> raiz;
    private int cont;

    @Override
    public boolean isEmpty() {
        return raiz == null;
    }//method

    @Override
    public int size() {
        return cont;
    }//method

    @Override
    public boolean contains(T elem) {
        if (isEmpty() || elem == null)
            return false;
        if (raiz.getElement().equals(elem))
            return true;            
        return contains(elem, raiz.getDer()) || contains(elem, raiz.getIzq());
    }//method

    private boolean contains(T elem, NodoBT nodo){
        if (nodo == null || nodo.element == null)
            return false;
        if (nodo.getElement().equals(elem))
            return true;
        return contains(elem, nodo.getDer()) || contains(elem, nodo.getDer());

    }//method

    @Override
    public T find(T elemento) {
        return null;
    }//method   

    @Override
    public Iterator<T> inOrden() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Iterator<T> preOrden() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Iterator<T> postOrden() {
        // TODO Auto-generated method stub
        return null;
    }
    
}//method